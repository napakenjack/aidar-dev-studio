export type PortfolioItem = {
  title: string
  category: string
  description: string
  image: string
  year: string
  tags: string[]
  href?: string
  isFeatured?: boolean
}

// Чтобы добавить новую работу:
// 1. Загрузи картинку в папку public/portfolio/
// 2. Скопируй один объект ниже и поменяй title, description, image, tags и href
// 3. image должен начинаться с /portfolio/, например: /portfolio/my-project.jpg
export const portfolioItems: PortfolioItem[] = [
  {
    title: 'Juye CRM для турагентств',
    category: 'CRM product',
    description:
      'Интерфейс для заявок, туристов, турпакетов, задач, статусов, туроператоров и менеджерской логики.',
    image: '/portfolio/juye-crm.svg',
    year: '2026',
    tags: ['CRM', 'Tour agency', 'Product UI'],
    href: '#',
    isFeatured: true,
  },
  {
    title: 'Сайт для бизнеса под заявки',
    category: 'Website',
    description:
      'Премиальная одностраничная структура: оффер, услуги, доверие, CTA, WhatsApp, адаптив и SEO-база.',
    image: '/portfolio/business-landing.svg',
    year: '2026',
    tags: ['React', 'Landing', 'Lead generation'],
    href: '#',
    isFeatured: true,
  },
  {
    title: 'AI-бот для онлайн-магазина',
    category: 'Automation',
    description:
      'FAQ, подбор товара, заявки, Google Sheets, уведомления и передача горячих лидов менеджеру.',
    image: '/portfolio/ai-bot.svg',
    year: '2026',
    tags: ['Telegram Bot', 'AI', 'Google Sheets'],
    href: '#',
    isFeatured: true,
  },
  {
    title: 'ERP-панель для строительной компании',
    category: 'ERP system',
    description:
      'Дашборд для проектов, материалов, сотрудников, задач, финансовых показателей и внутренних процессов.',
    image: '/portfolio/erp-dashboard.svg',
    year: '2026',
    tags: ['ERP', 'Dashboard', 'Operations'],
    href: '#',
  },
  {
    title: 'WordPress сайт для отеля',
    category: 'WordPress',
    description:
      'Кастомная тема с редактируемыми секциями, номерами, галереями, контактами и мобильной адаптацией.',
    image: '/portfolio/wordpress-hotel.svg',
    year: '2026',
    tags: ['WordPress', 'ACF', 'Hotel'],
    href: '#',
  },
  {
    title: 'Каталог автозапчастей',
    category: 'E-commerce',
    description:
      'Концепт каталога с поиском, карточками товаров, категориями, поставщиками и API-интеграциями.',
    image: '/portfolio/auto-parts.svg',
    year: '2026',
    tags: ['React', 'API', 'Catalog'],
    href: '#',
  },
]
